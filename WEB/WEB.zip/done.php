<?php

	if($_GET['timer'] and $_GET['song'] and $_GET['speed']) {
		echo "200 OK";
	}else{
		header('location: index.html');	
	};

	echo '

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<link rel="stylesheet" href="style.css">

<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<title>IGos Bot</title>
</head>
<body>
<div class="back">
	<h1>~ IGos BOT ~<?php echo"ppp";?></h1>
	<hr>
	<br>
	<div class="btncenter">
		<img src="media/centang.png" width="90px">
		<br>
		<br>
		<h2> Your Setup Has Done !</h2>
		<br>
		<br>		
		<a href="index.html">
		<button class="btn">BACK TO HOME</button></a>
	</div>
	
</div>
</body>
</html>





	';

?>